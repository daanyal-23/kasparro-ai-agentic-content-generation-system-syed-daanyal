# src/graph.py
import logging
from langgraph.graph import StateGraph, END
from src.models import ProductModel
from src.state import PipelineState
from src.agents.sanity_agent import run_sanity_checks
from src.agents.facts_extractor_agent import extract_facts
from src.agents.renderer_agent import write_outputs
from src.agents.validator_agent import validate_outputs
from src.langchain_orchestrator import (
    generate_product_page,
    generate_faq,
    generate_comparison,
)

logger = logging.getLogger("LangGraphPipeline")


# -----------------------------
# Graph Nodes
# -----------------------------
def sanity_node(state: PipelineState) -> PipelineState:
    # 🔑 Rehydrate ProductModel for legacy agents
    product_model = ProductModel.from_dict(state.product)

    product_model, issues = run_sanity_checks(product_model)

    # Store back as dict for graph state
    state.product = product_model.to_dict()
    state.sanity_issues = issues
    return state


def facts_node(state: PipelineState) -> PipelineState:
    product_model = ProductModel.from_dict(state.product)
    state.facts = extract_facts(product_model)
    return state


def product_page_node(state: PipelineState) -> PipelineState:
    state.product_page = generate_product_page(state.facts)
    return state


def faq_node(state: PipelineState) -> PipelineState:
    state.faq = generate_faq(state.facts)
    return state


def comparison_node(state: PipelineState) -> PipelineState:
    state.comparison = generate_comparison(state.facts)
    return state


def validate_node(state: PipelineState) -> PipelineState:
    return validate_outputs(state)


def render_node(state: PipelineState) -> PipelineState:
    write_outputs(
        product_page=state.product_page,
        faq=state.faq,
        comparison=state.comparison,
        outdir=state.outdir,
    )
    return state


# -----------------------------
# Router
# -----------------------------
def validation_router(state: PipelineState) -> str:
    return "render" if state.is_valid else END


# -----------------------------
# Graph Builder
# -----------------------------
def build_graph():
    graph = StateGraph(PipelineState)

    graph.add_node("sanity", sanity_node)
    graph.add_node("facts", facts_node)
    graph.add_node("product_page", product_page_node)
    graph.add_node("faq", faq_node)
    graph.add_node("comparison", comparison_node)
    graph.add_node("validate", validate_node)
    graph.add_node("render", render_node)

    graph.set_entry_point("sanity")

    graph.add_edge("sanity", "facts")
    graph.add_edge("facts", "product_page")
    graph.add_edge("product_page", "faq")
    graph.add_edge("faq", "comparison")
    graph.add_edge("comparison", "validate")

    graph.add_conditional_edges(
        "validate",
        validation_router,
        {"render": "render", END: END},
    )

    graph.add_edge("render", END)

    return graph.compile()


# -----------------------------
# Public Entry
# -----------------------------
def run_graph(input_path: str, outdir: str):
    from src.agents.ingest_agent import ingest_from_file

    product_model = ingest_from_file(input_path)

    initial_state = PipelineState(
        product=product_model.to_dict(),
        outdir=outdir,
    )

    graph = build_graph()
    return graph.invoke(initial_state)
