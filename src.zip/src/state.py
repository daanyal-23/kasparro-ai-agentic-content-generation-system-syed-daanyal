# src/state.py
from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field

class PipelineState(BaseModel):
    # core
    product: Dict[str, Any]

    # derived
    facts: Optional[Dict[str, Any]] = None
    product_page: Optional[Dict[str, Any]] = None
    faq: Optional[List[Dict[str, Any]]] = None
    comparison: Optional[Dict[str, Any]] = None

    # control & validation
    sanity_issues: List[str] = Field(default_factory=list)
    is_valid: bool = False
    error: Optional[str] = None
    errors: List[str] = Field(default_factory=list)

    # io
    outdir: Optional[str] = None
